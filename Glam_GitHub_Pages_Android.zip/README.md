# Glam — lista para GitHub Pages

## Publicarla
1. Entra a https://github.com desde el celular o computador e inicia sesión.
2. Crea un repositorio nuevo, por ejemplo `glam-maquillaje`.
3. Sube **todos** los archivos de esta carpeta a la raíz del repositorio: `index.html`, `manifest.json`, `service-worker.js` e `icon.svg`.
4. Abre **Settings → Pages**.
5. En **Build and deployment**, elige **Deploy from a branch**; selecciona `main` y `/ (root)` y guarda.
6. Espera a que GitHub Pages publique el sitio. La dirección tendrá esta forma: `https://TU-USUARIO.github.io/glam-maquillaje/`.

## Instalar en Android
1. Abre esa dirección con Chrome en Android (debe ser HTTPS).
2. Abre el menú ⋮ de Chrome.
3. Toca **Instalar aplicación** o **Añadir a pantalla principal** (el texto puede variar).
4. Confirma. Glam aparecerá como acceso en la pantalla de inicio y se abrirá en modo app.

## Importante
- No abras `index.html` directamente desde el administrador de archivos: la instalación PWA necesita un sitio HTTPS como GitHub Pages.
- Si haces cambios, vuelve a subir los archivos al repositorio y recarga el sitio.
- GitHub Pages aloja el sitio; no necesitas pagar para un repositorio público.
